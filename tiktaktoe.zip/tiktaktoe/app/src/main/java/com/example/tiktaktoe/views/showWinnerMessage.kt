package com.example.tiktaktoe.views

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview




@Composable
fun showWinnerMessage(player: String){
    Text(text = player)
}

@Preview
@Composable
fun showWinnerMessagePreview(){
    showWinnerMessage("Jaime")
}